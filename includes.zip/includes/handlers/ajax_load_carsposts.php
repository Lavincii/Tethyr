<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Carspost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new CarsPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadCarsPostsFriends($_REQUEST, $limit);
?>