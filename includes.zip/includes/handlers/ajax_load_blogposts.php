<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Blogpost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new BlogPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadBlogPostsFriends($_REQUEST, $limit);
?>