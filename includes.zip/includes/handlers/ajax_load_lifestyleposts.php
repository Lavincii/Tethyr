<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Lifestylepost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new LifestylePost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadLifestylePostsFriends($_REQUEST, $limit);
?>