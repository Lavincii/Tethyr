<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Sportspost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new SportsPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadSportsPostsFriends($_REQUEST, $limit);
?>