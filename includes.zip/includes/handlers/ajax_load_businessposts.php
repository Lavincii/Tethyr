<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Businesspost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new BusinessPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadBusinessPostsFriends($_REQUEST, $limit);
?>