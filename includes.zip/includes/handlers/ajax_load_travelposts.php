<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Travelpost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new TravelPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadTravelPostsFriends($_REQUEST, $limit);
?>