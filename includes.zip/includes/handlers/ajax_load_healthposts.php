<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Healthpost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new HealthPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadHealthPostsFriends($_REQUEST, $limit);
?>