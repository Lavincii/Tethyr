<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Entertainmentpost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new EntertainmentPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadEntertainmentPostsFriends($_REQUEST, $limit);
?>