<?php  
include("../../config/config.php");
include("../classes/User.php");
include("../classes/Familypost.php");

$limit = 10; //Number of posts to be loaded per call

$posts = new FamilyPost($con, $_REQUEST['userLoggedIn']);
echo $posts->loadFamilyPostsFriends($_REQUEST, $limit);
?>