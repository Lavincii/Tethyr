<?php 
require '../../config/config.php';
	
	if(isset($_GET['post_id']))
		$post_id = $_GET['post_id'];

	if(isset($_POST['result'])) {
		if($_POST['result'] == 'true')
			$query = mysqli_query($con, "UPDATE posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE blog_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE animal_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE health_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE travel_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE food_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE business_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE games_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE unexplained_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE sports_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE cars_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE lifestyle_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE family_posts SET deleted='yes' WHERE id='$post_id'");
			$query = mysqli_query($con, "UPDATE religion_posts SET deleted='yes' WHERE id='$post_id'");
	}

?>