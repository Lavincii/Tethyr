
  <!-- Tech Blogpost -->
  <div id = "blogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Technology Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="blogpost_text" id="blogpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
                    <h4><span class="char-blogcount">2500</span> Max</h4> <!--  500 Min  if needed-->
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="blogpost" id="post_button" value="Publish">
      <button onclick="closeBlogPost();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Animal Blogpost -->
  <div id = "AnimalblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Animals Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="animalpost_text" id="animalpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="animalpost" id="post_button" value="Publish">
      <button onclick="closeAnimalBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div>   

 <!-- Lifestyle Blogpost -->
  <div id = "LifestyleblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Lifestyle Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="lifestylepost_text" id="lifestylepost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="lifestylepost" id="post_button" value="Publish">
      <button onclick="closeLifestyleBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div>   

  <!-- Food Blogpost -->
  <div id = "FoodblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Food Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="foodpost_text" id="foodpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="foodpost" id="post_button" value="Publish">
      <button onclick="closeAnimalBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div>   

  <!-- Health Blogpost -->
  <div id = "HealthblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Health Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="healthpost_text" id="healthpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="healthpost" id="post_button" value="Publish">
      <button onclick="closeHealthBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div>   

  <!-- Travel Blogpost -->
  <div id = "TravelblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Travel Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="travelpost_text" id="travelpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="travelpost" id="post_button" value="Publish">
      <button onclick="closeTravelBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Business Blogpost -->
  <div id = "BusinessblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Business Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="businesspost_text" id="businesspost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="businesspost" id="post_button" value="Publish">
      <button onclick="closeBusinessBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Religion Blogpost -->
  <div id = "ReligionblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Religion Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="religionpost_text" id="religionpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="religionpost" id="post_button" value="Publish">
      <button onclick="closeReligionBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Sports Blogpost -->
  <div id = "SportsblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Sports Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="sportspost_text" id="sportspost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="sportspost" id="post_button" value="Publish">
      <button onclick="closeSportsBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Entertainment Blogpost -->
  <div id = "EntertainmentblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Entertainment Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="entertainmentpost_text" id="entertainmentpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="entertainmentpost" id="post_button" value="Publish">
      <button onclick="closeEntertainmentBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Cars Blogpost -->
  <div id = "CarsblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Cars Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="carspost_text" id="carspost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="carspost" id="post_button" value="Publish">
      <button onclick="closeCarsBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Family Blogpost -->
  <div id = "FamilyblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Family Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="familypost_text" id="familypost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="familypost" id="post_button" value="Publish">
      <button onclick="closeFamilyBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 

  <!-- Games Blogpost -->
  <div id = "GamesblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Games Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="gamespost_text" id="gamespost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="gamespost" id="post_button" value="Publish">
      <button onclick="closeGamesBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 


  <!-- Unexplained Blogpost -->
  <div id = "UnexplainedblogP" class = "post_blog_box">
 <form action="index.php" method="POST" enctype="multipart/form-data">
<div class="container">
  <div class="post-form">
    <div class="post-form-backdrop closed"></div>
    <div class="post-section editor-title">
      <h3 class="page-title">New Unexplained Post</h3>
    </div>
    <div class="post-section">
      <label for="post-title">Post Content</label>
      <div class="post-title">
        <input type="text" name="title" id="post-title" class="post-input large"  placeholder="Title..."/>
      </div>
      <div class="post-content">
        <textarea data-length=2500 name="unexplainedpost_text" id="unexplainedpost_text" class="post-input" placeholder="Content..."></textarea>
      </div>
    </div>
    <div class="post-section post-media">
      <label>Media</label>
      <div class="post-media-inner">
        <div class="post-media-icon thumbnail">
          <div class="delete-media btn btn-danger btn-xs">&times;</div>
          <img src="//placehold.it/150x150" alt="" />
        </div>
        <input class="post-media-icon btn btn-default" type="file" id="fileToUpload"></input>
      </div>
    </div>
    <div class="post-section post-buttons">
      <div class="dropup pull-left">
        <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" id="add-more-post-items">Add More <i class="caret"></i></button>
         <ul class="dropdown-menu" arial-labelledby="#add-more-post-items">
          <li><a href="#" class="open-overlay" data-target=".activities">Add Referral Links</a></li>
          <li><a href="#" class="open-overlay" data-target=".targets">Promote Post</a></li>
        </ul>
      </div>
      <button type="button" class="btn btn-primary">Save Draft</button>
      <input class = "btn btn-success" type="submit" name="unexplainedpost" id="post_button" value="Publish">
      <button onclick="closeUnexplainedBlog();" type="button" class="btn btn-danger">Cancel</button>
    </div>
    <div class="post-form-overlay closed activities">
      <h4>Add Referral Link<button type="button" class="close">&times;</button></h4>
      <p></p>
    </div>
    <div class="post-form-overlay closed targets">
      <h4>Add Target <button type="button" class="close">&times;</button></h4>
      <div class="form-group">
        <label for="target-text">Set Target:</label>
        <input autofocus id="target-text" type="text" class="form-control" />
      </div>
      <button class="btn btn-primary">Add</button>
    </div>
  </div>
</div>
</form>
</div> 
  
  <!-- post paramaters-->
  <script>

    $(".post-input").on("keyup",function(event){
  checkTextAreaMaxLength(this,event);
});

/*
Checks the MaxLength of the Textarea
-----------------------------------------------------
@prerequisite:  textBox = textarea dom element
        e = textarea event
                length = Max length of characters
*/
function checkTextAreaMaxLength(textBox, e) { 
    
    var maxLength = parseInt($(textBox).data("length"));
    
  
    if (!checkSpecialKeys(e)) { 
        if (textBox.value.length > maxLength - 1) textBox.value = textBox.value.substring(0, maxLength); 
   } 
  $(".char-blogcount").html(maxLength - textBox.value.length);
    
    return true; 
} 
/*
Checks if the keyCode pressed is inside special chars
-------------------------------------------------------
@prerequisite:  e = e.keyCode object for the key pressed
*/
function checkSpecialKeys(e) { 
    if (e.keyCode != 8 && e.keyCode != 46 && e.keyCode != 37 && e.keyCode != 38 && e.keyCode != 39 && e.keyCode != 40) 
        return false; 
    else 
        return true; 
}

  </script>