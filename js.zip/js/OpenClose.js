function openCloser() {
  document.getElementById("X_icon").style.display = "block";
}

function closeCloser() {
  document.getElementById("X_icon").style.display = "none";
}

function openNews() {
  document.getElementById("news_icon").style.display = "block";
}

function closeNews() {
  document.getElementById("news_icon").style.display = "none";
}

function openRss() {
  document.getElementById("open_News").style.display = "block";
}

function closeRss() {
  document.getElementById("open_News").style.display = "none";
}

function openIcon() {
  document.getElementById("T_icon").style.display = "block";
}

function closeIcon() {
  document.getElementById("T_icon").style.display = "none";
}

function openForm() {
  document.getElementById("myForm").style.display = "block";
}

function closeForm() {
  document.getElementById("myForm").style.display = "none";
}

function openTools() {
  document.getElementById("toolbar").style.display = "block";
}

function closeTools() {
  document.getElementById("toolbar").style.display = "none";
}

function openToolNote() {
  document.getElementById("toolnote").style.display = "block";
}

function closeToolNote() {
  document.getElementById("toolnote").style.display = "none";
}

function openBox() {

    document.getElementById("lookup_box").style.display = "block";
  }
function closeBox() {

    document.getElementById("lookup_box").style.display = "none";

}

function openAddT() {

    document.getElementById("tether_icon").style.display = "block";
  }
function closeAddT() {

    document.getElementById("tether_icon").style.display = "none";

}

function openNotepad() {

    document.getElementById("notepad").style.display = "block";
  }
function closeNotepad() {

    document.getElementById("notepad").style.display = "none";

}

function openWeather() {

    document.getElementById("weather").style.display = "block";
  }
function closeWeather() {

    document.getElementById("weather").style.display = "none";

}

function openWeatherBox() {

    document.getElementById("weather_box").style.display = "block";
  }

function closeWeatherBox() {

    document.getElementById("weather_box").style.display = "none";

}

function addtech() {

    document.getElementById("Tech_category").style.display = "block";
  }

function removetech() {

    document.getElementById("Tech_category").style.display = "none";

}

function addAnimal() {

    document.getElementById("Animal_category").style.display = "block";
  }

function removeAnimal() {

    document.getElementById("Animal_category").style.display = "none";
}

function addFood() {

    document.getElementById("Food_category").style.display = "block";
  }

function removeFood() {

    document.getElementById("Food_category").style.display = "none";

}

function addHealth() {

    document.getElementById("Health_category").style.display = "block";
  }

function removeHealth() {

    document.getElementById("Health_category").style.display = "none";

}

function addTravel() {

    document.getElementById("Travel_category").style.display = "block";
  }
function removeTravel() {

    document.getElementById("Travel_category").style.display = "none";

}

function addBusiness() {

    document.getElementById("Business_category").style.display = "block";
  }

function removeBusiness() {

    document.getElementById("Business_category").style.display = "none";

}

function addLifestyle() {

    document.getElementById("Lifestyle_category").style.display = "block";
  }

function removeLifestyle() {

    document.getElementById("Lifestyle_category").style.display = "none";

}

function addEntertainment() {

    document.getElementById("Entertainment_category").style.display = "block";
  }

function removeEntertainment() {

    document.getElementById("Entertainment_category").style.display = "none";

}

function addSports() {

    document.getElementById("Sports_category").style.display = "block";
  }
function removeSports() {

    document.getElementById("Sports_category").style.display = "none";

}

function addCars() {

    document.getElementById("Cars_category").style.display = "block";
  }
function removeCars() {

    document.getElementById("Cars_category").style.display = "none";

}

function addFamily() {

    document.getElementById("Family_category").style.display = "block";
  }
function removeFamily() {

    document.getElementById("Family_category").style.display = "none";

}

function addReligion() {

    document.getElementById("Religion_category").style.display = "block";
  }
function removeReligion() {

    document.getElementById("Religion_category").style.display = "none";

}

function addUnexplained() {

    document.getElementById("Unexplained_category").style.display = "block";
  }
function removeUnexplained() {

    document.getElementById("Unexplained_category").style.display = "none";

}

function addGames() {

    document.getElementById("Games_category").style.display = "block";
  }
function removeGames() {

    document.getElementById("Games_category").style.display = "none";

}

function openTech() {

    document.getElementById("tech").style.display = "block";
  }
function closeTech() {

    document.getElementById("tech").style.display = "none";

}

function openTechB() {

    document.getElementById("techB").style.display = "block";
  }
function closeTechB() {

    document.getElementById("techB").style.display = "none";

}
function openAnimal() {

    document.getElementById("animal").style.display = "block";
  }
function closeAnimal() {

    document.getElementById("animal").style.display = "none";

}

function openAnimalB() {

    document.getElementById("animalB").style.display = "block";
  }
function closeAnimalB() {

    document.getElementById("animalB").style.display = "none";

}

function openLifestyle() {

    document.getElementById("lifestyle").style.display = "block";
  }
function closeLifestyle() {

    document.getElementById("lifestyle").style.display = "none";

}

function openLifestyleB() {

    document.getElementById("lifestyleB").style.display = "block";
  }
function closeLifestyleB() {

    document.getElementById("lifestyleB").style.display = "none";

}

function openFood() {

    document.getElementById("food").style.display = "block";
  }
function closeFood() {

    document.getElementById("food").style.display = "none";

}

function openFoodB() {

    document.getElementById("foodB").style.display = "block";
  }
function closeFoodB() {

    document.getElementById("foodB").style.display = "none";

}

function openHealth() {

    document.getElementById("health").style.display = "block";
  }
function closeHealth() {

    document.getElementById("health").style.display = "none";

}

function openHealthB() {

    document.getElementById("healthB").style.display = "block";
  }
function closeHealthB() {

    document.getElementById("healthB").style.display = "none";

}

function openBusiness() {

    document.getElementById("business").style.display = "block";
  }
function closeBusiness() {

    document.getElementById("business").style.display = "none";

}

function openBusinessB() {

    document.getElementById("businessB").style.display = "block";
  }
function closeBusinessB() {

    document.getElementById("businessB").style.display = "none";

}

function openTravel() {

    document.getElementById("travel").style.display = "block";
  }
function closeTravel() {

    document.getElementById("travel").style.display = "none";

}

function openTravelB() { 

    document.getElementById("travelB").style.display = "block";
  }
function closeTravelB() {

    document.getElementById("travelB").style.display = "none";

}

function openCars() {

    document.getElementById("cars").style.display = "block";
  }
function closeCars() {

    document.getElementById("cars").style.display = "none";

}

function openCarsB() {

    document.getElementById("carsB").style.display = "block";
  }
function closeCarsB() {

    document.getElementById("carsB").style.display = "none";

}

function openFamily() {

    document.getElementById("family").style.display = "block";
  }
function closeFamily() {

    document.getElementById("family").style.display = "none";

}

function openFamilyB() {

    document.getElementById("familyB").style.display = "block";
  }
function closeFamilyB() {

    document.getElementById("familyB").style.display = "none";

}

function openGames() {

    document.getElementById("games").style.display = "block";
  }
function closeGames() {

    document.getElementById("games").style.display = "none";

}
 
function openGamesB() {

    document.getElementById("gamesB").style.display = "block";
  }
function closeGamesB() {

    document.getElementById("gamesB").style.display = "none";

}

function openReligion() {

    document.getElementById("religion").style.display = "block";
  }
function closeReligion() {

    document.getElementById("religion").style.display = "none";

}
 
function openReligionB() {

    document.getElementById("religionB").style.display = "block";
  }
function closeReligionB() {

    document.getElementById("religionB").style.display = "none";

}

function openEntertainment() {

    document.getElementById("entertainment").style.display = "block";
  }
function closeEntertainment() {

    document.getElementById("entertainment").style.display = "none";

}
 
function openEntertainmentB() {

    document.getElementById("entertainmentB").style.display = "block";
  }
function closeEntertainmentB() {

    document.getElementById("entertainmentB").style.display = "none";

}

function openSports() {

    document.getElementById("sports").style.display = "block";
  }
function closeSports() {

    document.getElementById("sports").style.display = "none";

}
 
function openSportsB() {

    document.getElementById("sportsB").style.display = "block";
  }
function closeSportsB() {

    document.getElementById("sportsB").style.display = "none";

}

function openUnexplained() {

    document.getElementById("unexplained").style.display = "block";
  }
function closeUnexplained() {

    document.getElementById("unexplained").style.display = "none";

}
 
function openUnexplainedB() {

    document.getElementById("unexplainedB").style.display = "block";
  }
function closeUnexplainedB() {

    document.getElementById("unexplainedB").style.display = "none";

}
 
function postBlog() {

    document.getElementById("blogP").style.display = "block";
  }
function closeBlogPost() {

    document.getElementById("blogP").style.display = "none";

}

function postAnimalBlog() {

    document.getElementById("AnimalblogP").style.display = "block";
  }
function closeAnimalBlog() {

    document.getElementById("AnimalblogP").style.display = "none";

}

function postFoodBlog() {

    document.getElementById("FoodblogP").style.display = "block";
  }
function closeFoodBlog() {

    document.getElementById("FoodblogP").style.display = "none";

}
 
function postHealthBlog() {

    document.getElementById("HealthblogP").style.display = "block";
  }
function closeHealthBlog() {

    document.getElementById("HealthblogP").style.display = "none";

}
 
function postTravelBlog() {

    document.getElementById("TravelblogP").style.display = "block";
  }
function closeTravelBlog() {

    document.getElementById("TravelblogP").style.display = "none";

}
 
function postLifestyleBlog() {

    document.getElementById("LifestyleblogP").style.display = "block";
  }
function closeLifestyleBlog() {

    document.getElementById("LifestyleblogP").style.display = "none";

}
 
function postBusinessBlog() {

    document.getElementById("BusinessblogP").style.display = "block";
  }
function closeBusinessBlog() {

    document.getElementById("BusinessblogP").style.display = "none";

}
 
function postReligionBlog() {

    document.getElementById("ReligionblogP").style.display = "block";
  }
function closeReligionBlog() {

    document.getElementById("ReligionblogP").style.display = "none";

}
 
function postSportsBlog() {

    document.getElementById("SportsblogP").style.display = "block";
  }
function closeSportsBlog() {

    document.getElementById("SportsblogP").style.display = "none";

}
 
function postEntertainmentBlog() {

    document.getElementById("EntertainmentblogP").style.display = "block";
  }
function closeEntertainmentBlog() {

    document.getElementById("EntertainmentblogP").style.display = "none";

}
 
function postCarsBlog() {

    document.getElementById("CarsblogP").style.display = "block";
  }
function closeCarsBlog() {

    document.getElementById("CarsblogP").style.display = "none";

}
 
function postFamilyBlog() {

    document.getElementById("FamilyblogP").style.display = "block";
  }
function closeFamilyBlog() {

    document.getElementById("FamilyblogP").style.display = "none";

}
 
function postGamesBlog() {

    document.getElementById("GamesblogP").style.display = "block";
  }
function closeGamesBlog() {

    document.getElementById("GamesblogP").style.display = "none";

}
 
function postUnexplainedBlog() {

    document.getElementById("UnexplainedblogP").style.display = "block";
  }
function closeUnexplainedBlog() {

    document.getElementById("UnexplainedblogP").style.display = "none";

}
 
function openPoll() {

    document.getElementById("poll").style.display = "block";
  }
function closePoll() {

    document.getElementById("poll").style.display = "none";

}
 
function openCompare() {

    document.getElementById("compare").style.display = "block";
  }
function closeCompare() {

    document.getElementById("compare").style.display = "none";

}